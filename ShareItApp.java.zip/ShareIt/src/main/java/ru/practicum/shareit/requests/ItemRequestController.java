package ru.practicum.shareit.requests;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * // TODO в следующем спринте.
 */
@RestController
@RequestMapping(path = "/requests")
public class ItemRequestController {
}
