package ru.practicum.shareit.requests.model;

/**
 * // TODO в следующем спринте.
 */
public class ItemRequest {
}
