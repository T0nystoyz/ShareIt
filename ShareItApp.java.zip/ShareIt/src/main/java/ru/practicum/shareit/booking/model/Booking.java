package ru.practicum.shareit.booking.model;

/**
 * // TODO в следующем спринте.
 */
public class Booking {
}
