package ru.practicum.shareit.booking;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * // TODO в следующем спринте.
 */
@RestController
@RequestMapping(path = "/bookings")
public class BookingController {
}
