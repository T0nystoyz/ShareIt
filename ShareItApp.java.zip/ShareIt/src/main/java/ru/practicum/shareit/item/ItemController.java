package ru.practicum.shareit.item;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import ru.practicum.shareit.item.model.ItemDTO;
import ru.practicum.shareit.item.service.ItemService;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/items")
public class ItemController {
    private final ItemService itemService;

    @PostMapping
    public ItemDTO createItem(
            @RequestHeader("X-Sharer-User-Id") long userId,
            @RequestBody ItemDTO itemDto
    ) {
        return itemService.create(userId, itemDto);
    }

    @GetMapping("/{itemId}")
    public ItemDTO getItemById(
            @PathVariable long itemId
    ) {
        return itemService.read(itemId);
    }

    @PatchMapping("/{itemId}")
    public ItemDTO updateItem(
            @RequestHeader("X-Sharer-User-Id") long userId,
            @PathVariable long itemId,
            @RequestBody ItemDTO itemDto
    ) {
        return itemService.update(userId, itemId, itemDto);
    }

    @GetMapping
    public List<ItemDTO> getAllItemsByOwner(
            @RequestHeader("X-Sharer-User-Id") long userId
    ) {
        return itemService.getOwnersItems(userId);
    }

    @GetMapping("/search")
    public List<ItemDTO> getItemBySubstring(
            @RequestHeader("X-Sharer-User-Id") long userId,
            @RequestParam String text
    ) {
        return itemService.findItemsByText(userId, text);
    }
}
